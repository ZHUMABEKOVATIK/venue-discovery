from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.sessions import get_async_session
from src.repositories.venue import VenueRepo
from src.services.venue import VenueService

def get_venue_repo(session: AsyncSession = Depends(get_async_session)) -> VenueRepo:
    return VenueRepo(session)

def get_venue_service(repo: VenueRepo = Depends(get_venue_repo)) -> VenueService:
    return VenueService(repo)